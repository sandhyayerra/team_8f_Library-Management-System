from django.db import models
# library/models.py
from django.contrib.auth.models import User

# Create your models here.

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=30, default='username')
	password = models.CharField(max_length=10, default='example')
	email = models.CharField(max_length=30, default='example@gmail.com')
def __str__(self):
  	return self.UserProfileInfo.username, self.UserProfileInfo.Password

TITLE_CHOICES = (
	('Python Programming','PYTHON PRPGRAMMING'),
	('Higher Mathematics','HIGHER MATHEMATICS'),
	('Telephone Electronics','TELEPHONE ELECTRONICS'),
	('PING Magazine','PING MAGAZINE'),
	('Organic Chemistry','ORGANIC CHEMISTRY'),
	('Educated (Novel)','EDUCATED (NOVEL)')
	)

class Details(models.Model):
	name = models.CharField(max_length = 30, default = 'name')
	title = models.CharField(max_length = 30, choices = TITLE_CHOICES, default = '')
	phonenumber = models.CharField(max_length=12)
	date = models.DateField(max_length = 25, default = 'yyyy-mm-dd')	

	




