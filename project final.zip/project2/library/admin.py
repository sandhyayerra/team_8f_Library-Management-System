# library/admin.py

from django.contrib import admin
from library.models import UserProfileInfo
from library.models import Details


# Register your models here.

admin.site.register(UserProfileInfo)
admin.site.register(Details)


# Register your models here.
