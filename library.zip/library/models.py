from django.db import models
# library/models.py
from django.contrib.auth.models import User

# Create your models here.

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=30, default='username')
	password = models.CharField(max_length=10, default='example')
	email = models.CharField(max_length=30, default='example@gmail.com')
def __str__(self):
  	return self.UserProfileInfo.username, self.UserProfileInfo.Password




