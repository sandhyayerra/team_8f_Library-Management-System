# library/admin.py

from django.contrib import admin
from library.models import UserProfileInfo
# Register your models here.

admin.site.register(UserProfileInfo)


# Register your models here.
