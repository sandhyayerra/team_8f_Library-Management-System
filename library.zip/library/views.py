from django.shortcuts import render
from library.forms import UserForm 
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from library.models import UserProfileInfo

def index(request):
	return render(request, 'index.html')
# library/views.py

@login_required
def special(request):
    return HttpResponse("You are logged in !")

def user_logout(request):
    logout(request)
    return render(request, 'index.html')

def welcome(request):
	return render(request, 'welcome.html')

def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
       # profile_form = UserProfileInfoForm(data=request.POST)
        if user_form.is_valid():
            user = user_form.save()
            #user.set_password(user.password)
            user.save()
            registered = True
            return render(request,'index.html',
                          {'user_form':user_form,
                           'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
       # profile_form = UserProfileInfoForm()
    return render(request,'register.html',{'user_form':user_form,'registered':registered})

def user_login(request):
	if request.method == 'POST':
		username = request.POST.get('username')
		password = request.POST.get('password')
		a=UserProfileInfo.objects.filter(username=username).exists()
		b=UserProfileInfo.objects.filter(password=password).exists()
		if a and b:
			return HttpResponseRedirect(reverse('welcome'))
		else:
			print("Someone tried to login and failed.")
			print("They used username: {} and password: {}".format(username,password))
			return HttpResponse("Invalid login details given")
	else:
		return render(request, 'user_login.html')
